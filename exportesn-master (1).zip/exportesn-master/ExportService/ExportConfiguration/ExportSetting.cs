﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExportService
{
    public class ExportSetting : ConfigurationSectionGroup
    {
        //[ConfigurationProperty("setting", IsRequired = false)]
        //public SettingSection GeneralSettings
        //{
        //    get { return (SettingSection)base.Sections["setting"]; }
        //}

        //[ConfigurationProperty("companySection22", IsRequired = false)]
        //public TableSection ContextSettings
        //{
        //    get { return (TableSection)base.Sections["companySection22"]; }
        //}

        


    }
}
